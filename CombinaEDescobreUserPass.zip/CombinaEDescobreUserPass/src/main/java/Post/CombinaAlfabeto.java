package Post;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author Analice
 */
public class CombinaAlfabeto {

    public static List<String> combinarLetras() {
        List<String> combinacoes = new ArrayList<>();
        String alfabeto = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

        for (int i = 0; i < alfabeto.length() - 3; i++) {
            for (int j = i + 1; j < alfabeto.length() - 2; j++) {
                for (int k = j + 1; k < alfabeto.length() - 1; k++) {
                    for (int l = k + 1; l < alfabeto.length(); l++) {
                        String combinacao = "" + alfabeto.charAt(i) + alfabeto.charAt(j) + alfabeto.charAt(k) + alfabeto.charAt(l);
                        combinacoes.add(combinacao);
                    }
                }
            }
        }

        System.out.println("Número de combinações: " + combinacoes.size());
        return combinacoes;
    }

    public static String gerarSenha(List<String> combinacoes) {
        Random random = new Random();

        if (!combinacoes.isEmpty()) {
            int index = random.nextInt(combinacoes.size());
            return combinacoes.get(index);
        }

        return null;
    }

    public static void main(String[] args) {
        List<String> resultado = combinarLetras();
        for (String combinacao : resultado) {
            System.out.println(combinacao);
        }
    }

//        List<String> combinacoes = combinarLetras();
//        String senha = gerarSenha(combinacoes);
//
//        if (senha != null) {
//            System.out.println("Senha gerada: " + senha);
//        } else {
//            System.out.println("Não foi possível gerar a senha.");
//        }
//    }

}
