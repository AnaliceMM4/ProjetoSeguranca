package Post;

/**
 *
 * @author Analice
 */
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.apache.http.entity.StringEntity;

public class Post {

    private static String senha;
    private static String usuario;

    public static void main(String[] args) {

        String url = args[0]; // obtém a URL a partir do primeiro argumento

        try {
            URL urlObject = new URL(url);

            // restante do código
        } catch (Exception e) {
            e.printStackTrace();
        }
//        try {
//            URL url = new URL("http://127.0.0.1:8090/login");
//
//            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//            connection.setRequestMethod("POST");
//            connection.setRequestProperty("Content-Type", "application/json");
//            connection.setDoOutput(true);
//
//            String jsonInputString = "{\"usuario\": \"" + usuario + "\", \"senha\": \"" + senha + "\"}";
//
//            try ( OutputStream os = connection.getOutputStream()) {
//                byte[] input = jsonInputString.getBytes("utf-8");
//                os.write(input, 0, input.length);
//            }
//
//            try ( BufferedReader br = new BufferedReader(
//                    new InputStreamReader(connection.getInputStream(), "utf-8"))) {
//                StringBuilder response = new StringBuilder();
//                String responseLine = null;
//                while ((responseLine = br.readLine()) != null) {
//                    response.append(responseLine.trim());
//                }
//                System.out.println(response.toString());
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

    }

}
