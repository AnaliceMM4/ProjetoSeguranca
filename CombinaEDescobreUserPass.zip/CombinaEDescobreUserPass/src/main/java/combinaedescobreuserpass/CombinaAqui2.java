package combinaedescobreuserpass;

import Post.Post;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

public class CombinaAqui2 {

    public static void main(String[] args) throws IOException {

        // 1. Ler os arquivos de texto que contêm usuários e senhas
        ArrayList<String> usuariosteste = new ArrayList<>();
        ArrayList<String> senhasteste = new ArrayList<>();
        BufferedReader usuarioReader = new BufferedReader(new FileReader("C:\\Users\\User\\Documents\\teste0105\\usuario.txt"));
        BufferedReader senhaReader = new BufferedReader(new FileReader("C:\\Users\\User\\Documents\\teste0105\\senha.txt"));
        BufferedReader combinacoesReader = new BufferedReader(new FileReader("C:\\\\Users\\\\User\\\\Documents\\\\teste0105\\\\usuariosenhacerto.txt"));

        // 2. Armazenar os usuários e senhas em arrays
        String linha;
        while ((linha = usuarioReader.readLine()) != null) {
            if (!linha.trim().isEmpty()) {
                usuariosteste.add(linha);
            }
        }
        String[] usuarios = usuariosteste.toArray(new String[0]);
        System.out.println("USUÁRIOS: " + usuariosteste);

        while ((linha = senhaReader.readLine()) != null) {
            if (!linha.trim().isEmpty()) {
                senhasteste.add(linha);
            }
        }
        String[] senhas = senhasteste.toArray(new String[0]);
        System.out.println("SENHAS: " + senhasteste);

        // 3. Gerar todas as possíveis combinações de usuários e senhas
        for (int i = 0; i < usuarios.length; i++) {
            for (int j = 0; j < senhas.length; j++) {
                String combinacao = "User " + usuarios[i] + "\tPassword " + senhas[j];
                System.out.println("COMBINAÇÕES: " + combinacao);
            }
        }

        // 4. Comparar as combinações com outro arquivo de texto
        while ((linha = combinacoesReader.readLine()) != null) {
            String[] partes = linha.split(":");
            String usuario = partes[0];
            String senha = partes[1];

            boolean encontrouComb = false;

            for (int i = 0; i < usuarios.length; i++) {
                if (usuarios[i].equals(usuario)) {
                    for (int j = 0; j < senhas.length; j++) {
                        if (senhas[j].equals(senha)) {
                            encontrouComb = true;
                            break;
                        }
                    }
                }
                if (encontrouComb) {
                    break;
                }
            }
            if (encontrouComb) {
                System.out.println("\nCombinação correta encontrada: " + linha);
            } else {
                System.out.println("\nCombinação incorreta: " + linha);
            }
        }

        String url = "http://localhost:8090/login"; // substitua com a URL correta
        Post.main(new String[]{url});

//        String url = "http://127.0.0.1:8090/login";
//        CloseableHttpClient httpClient = HttpClients.createDefault();
//
//        for (String usuario : usuariosteste) {
//            for (String senha : senhasteste) {
//                try {
//                    Post httpPost = new Post();
//                    String jsonInputString = "{\"usuario\": \"" + usuario + "\", \"senha\": \"" + senha + "\"}";
//                    StringEntity entity = new StringEntity(jsonInputString);
//                    httpPost.setEntity(entity);
//                    httpPost.setHeader("Accept", "application/json");
//                    httpPost.setHeader("Content-type", "application/json");
//
//                    HttpResponse response = httpClient.execute(httpPost);
//                    int statusCode = response.getStatusLine().getStatusCode();
//                    if (statusCode == 200) {
//                        System.out.println("Combinação correta: usuário " + usuario + " e senha " + senha);
//                        return;
//                    } else {
//                        System.out.println("Combinação inválida: usuário " + usuario + " e senha " + senha);
//                    }
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        }
        // 5. Fechar os leitores de arquivos
        usuarioReader.close();
        senhaReader.close();
        combinacoesReader.close();
    }

}
