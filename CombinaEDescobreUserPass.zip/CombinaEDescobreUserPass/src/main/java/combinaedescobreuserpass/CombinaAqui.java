//ESSE NÃO
//package combinaedescobreuserpass;
//
///**
// *
// * @author Analice
// */
//import java.io.BufferedReader;
//import java.io.File;
//import java.io.FileNotFoundException;
//import java.io.FileReader;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.Scanner;
//
//public class CombinaAqui {
//
//    public static void main(String[] args) throws FileNotFoundException {
//
////        File usuariofile = new File("C:\\Users\\User\\Documents\\teste0105\\usuario.txt");
////        File senhaf = new File("C:\\Users\\User\\Documents\\teste0105\\senha.txt");
////        File usuariosenha = new File("C:\\Users\\User\\Documents\\teste0105\\usuariosenhacerto.txt");
////
////        Scanner usuarioReader = new Scanner(usuariofile);
////        String caminhoUsuarios = usuarioReader.nextLine();
////
////        Scanner senhaReader = new Scanner(senhaf);
////        String caminhoSenhas = senhaReader.nextLine();
////
////        Scanner combinacoesReader = new Scanner(usuariosenha);
////        String caminhoCombinacoes = combinacoesReader.nextLine();
//        // 1. Ler os arquivos de texto que contêm usuários e senhas
//        BufferedReader usuarioReader = null;
//        BufferedReader senhaReader = null;
//        BufferedReader combinacoesReader = null;
//        try {
//            ArrayList<String> usuariosteste;
//            ArrayList<String> senhasteste;
//            int index;
//            String linha;
//            String[] usuarios;
//
//            try (usuarioReader = new BufferedReader(new FileReader("C:\\Users\\User\\Documents\\teste0105\\usuario.txt"))) {
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//            try (senhaReader = new BufferedReader(new FileReader("C:\\Users\\User\\Documents\\teste0105\\senha.txt"))) {
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//
//            try (combinacoesReader = new BufferedReader(new FileReader("C:\\Users\\User\\Documents\\teste0105\\usuariosenhacerto.txt"))) {
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//            usuariosteste = new ArrayList<String>();
//            senhasteste = new ArrayList<String>();
////            Scanner sc = new Scanner(System.in);
////            System.out.println("Digite o caminho completo para o arquivo de usuários:");
////            String caminhoUsuarios = sc.nextLine();
////            System.out.println("Digite o caminho completo para o arquivo de senhas:");
////            String caminhoSenhas = sc.nextLine();
////            System.out.println("Digite o caminho completo para o arquivo de combinações corretas:");
////            String caminhoCombinacoes = sc.nextLine();
////            usuarioReader = new BufferedReader(new FileReader(caminhoUsuarios));
////            senhaReader = new BufferedReader(new FileReader(caminhoSenhas));
////            combinacoesReader = new BufferedReader(new FileReader(caminhoCombinacoes));
//            index = 0;
//            // 2. Armazenar os usuários e senhas em arrays
//            while ((linha = usuarioReader.readLine()) != null) {
//                if (!linha.trim().isEmpty()) {
//                    usuariosteste.add(linha);
////                    usuarios[index] = linha;
////                    System.out.println("USUARIO: " + usuarios[index]);;
////                    index++;
//                }
//            }
//            usuarios = usuariosteste.toArray(new String[0]); // ou o tamanho que precisar;
//            for (int i = 0; i < usuarios.length; i++) {
//                System.out.println("USUARIO: " + usuarios[i]);
//            }
//            System.out.println("Testando o usuario" + usuariosteste);
//        
//
//        index = 0;
//
//        while ((linha = senhaReader.readLine()) != null) {
//            if (!linha.trim().isEmpty()) {
//                senhasteste.add(linha);
//            }
//        }
//        String[] senhas = senhasteste.toArray(new String[0]); // ou o tamanho que precisar;
//        for (int i = 0; i < senhas.length; i++) {
//            System.out.println("SENHA: " + senhas[i]);
//        }
//        System.out.println("Testando a senha" + senhasteste);
//
////            senhaReader.close();
//        // 3. Gerar todas as possíveis combinações de usuários e senhas
////            for (int i = 0; i < usuarios.length; i++) {;
////                for (int j = 0; j < senhas.length; j++) {;
////                    String combinacao = usuarios[i] + ":" + senhas[j];
////                    System.out.println("COMBINAÇÕES: " + combinacao);
////
////                }
////            }
//        for (int i = 0; i < usuariosteste.size(); i++) {
//            for (int j = 0; j < senhasteste.size(); j++) {
//                String combinacao = "User " + usuarios[i] + "\tPassword " + senhas[j];
//                System.out.println("COMBINAÇÕES = " + combinacao);
//
//            }
//        }
//
//        // 4. Comparar as combinações com outro arquivo de texto
//        while ((linha = combinacoesReader.readLine()) != null) {
//            String[] partes = linha.split(":");
//            String usuario = partes[0];
//            String senha = partes[1];
//
//            boolean encontrouComb = false;
//
//            for (int i = 0; i < usuariosteste.size(); i++) {
//                if (usuarios[i] != null && usuarios[i].equals(usuario)) {
//                    for (int j = 0; j < senhasteste.size(); j++) {
//                        if (senhas[j] != null && senhas[j].equals(senha)) {
//                            encontrouComb = true;
//                            System.out.println("\nCombinação Encontrada: " + linha);
//                            break;
//                        }
//                    }
//                    if (encontrouComb) {
//                        break;
//                    }
//                }
//            }
//        }
//
//    }
// catch (IOException e) {
//            e.printStackTrace();
//        }
//
////    finally {;
////        try {
////            if (usuarioReader != null) {
////                usuarioReader.close();
////            }
////            if (senhaReader != null) {
////                senhaReader.close();
////            }
////            if (combinacoesReader != null) {
////                combinacoesReader.close();
////            }
////        } catch (IOException e) {
////            e.printStackTrace();
////        }
////    }
//}
//
//}
