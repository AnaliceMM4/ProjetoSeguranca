package combinaedescobreuserpass;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author Analice
 */
public class Combinacoes4e6e8Caracteres {

    private static final List<String> combinacoes = new ArrayList<>();
    private static final String alfabeto = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String numeros = "0123456789";

    //4 CARACTERES
    public static List<String> combinar4Letras() {

        for (int i = 0; i < alfabeto.length() - 3; i++) {
            for (int j = i; j < alfabeto.length() - 2; j++) {
                for (int k = j; k < alfabeto.length() - 1; k++) {
                    for (int l = k; l < alfabeto.length(); l++) {
                        String combinacao = "" + alfabeto.charAt(i)
                                + alfabeto.charAt(j) + alfabeto.charAt(k) + alfabeto.charAt(l);
                        combinacoes.add(combinacao);
                    }
                }
            }
        }

        System.out.println("Número de combinações com 4 caracteres: " + combinacoes.size());
        return combinacoes;
    }

    //6 CARACTERES
    public static List<String> combinar6LetrasNumeros() {

        for (int i = 0; i < alfabeto.length() - 3; i++) {
            for (int j = i; j < alfabeto.length() - 2; j++) {
                for (int k = j; k < alfabeto.length() - 1; k++) {
                    for (int l = k; l < alfabeto.length(); l++) {
                        for (int m = 0; m < numeros.length() - 1; m++) {
                            for (int n = m; n < numeros.length(); n++) {
                                String combinacao = "" + alfabeto.charAt(i)
                                        + alfabeto.charAt(j) + alfabeto.charAt(k)
                                        + alfabeto.charAt(l) + numeros.charAt(m) + numeros.charAt(n);
                                combinacoes.add(combinacao);
                            }
                        }
                    }
                }
            }
        }

        // Embaralhar as combinações
//        Collections.shuffle(combinacoes);
        System.out.println("Número de combinações com 6 caracteres: " + combinacoes.size());
        return combinacoes;
    }

    //8 CARACTERES
    public static List<String> combinar8LetrasNumeros() {
        List<String> combinacoes = new ArrayList<>();

        for (int g = 0; g < alfabeto.length() - 5; g++) {
            for (int h = g + 1; h < alfabeto.length() - 4; h++) {
                for (int i = h + 1; i < alfabeto.length() - 3; i++) {
                    for (int j = i + 1; j < alfabeto.length() - 2; j++) {
                        for (int k = j + 1; k < alfabeto.length() - 1; k++) {
                            for (int l = k + 1; l < alfabeto.length(); l++) {
                                for (int m = 0; m < numeros.length() - 1; m++) {
                                    for (int n = m + 1; n < numeros.length(); n++) {
                                        String combinacao = "" + alfabeto.charAt(g)
                                                + alfabeto.charAt(h) + alfabeto.charAt(i)
                                                + alfabeto.charAt(j) + alfabeto.charAt(k)
                                                + alfabeto.charAt(l) + numeros.charAt(m) + numeros.charAt(n);
                                        combinacoes.add(combinacao);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

//        Collections.shuffle(combinacoes);
        System.out.println("Número de combinações com 8 caracteres: " + combinacoes.size());
        return combinacoes;
    }

    public static void main(String[] args) {
        combinar4Letras();
        combinar6LetrasNumeros();

//        combinar8LetrasNumeros();
    }
}
