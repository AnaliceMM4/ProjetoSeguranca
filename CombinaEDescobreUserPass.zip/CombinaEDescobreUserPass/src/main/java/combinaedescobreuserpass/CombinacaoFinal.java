package combinaedescobreuserpass;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.io.FileReader;
import java.util.Collections;

/**
 *
 * @author Analice
 */
public class CombinacaoFinal {

    public static List<String> combinarLetras() {
        List<String> combinacoes = new ArrayList<>();
        String alfabeto = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String numeros = "0123456789";

        for (int i = 0; i < alfabeto.length() - 3; i++) {
            for (int j = i; j < alfabeto.length() - 2; j++) {
                for (int k = j; k < alfabeto.length() - 1; k++) {
                    for (int l = k; l < alfabeto.length(); l++) {
                        for (int m = 0; m < numeros.length() - 1; m++) {
                            for (int n = m; n < numeros.length(); n++) {
                                String combinacao = "" + alfabeto.charAt(i)
                                        + alfabeto.charAt(j) + alfabeto.charAt(k)
                                        + alfabeto.charAt(l) + numeros.charAt(m) + numeros.charAt(n);
                                combinacoes.add(combinacao);
                            }
                        }
                    }
                }
            }
        }

//        for (int i = 0; i < alfabeto.length() - 4; i++) {
//            for (int j = i + 1; j < alfabeto.length() - 3; j++) {
//                for (int k = j + 1; k < alfabeto.length() - 2; k++) {
//                    for (int l = k + 1; l < alfabeto.length() - 1; l++) {
//                        for (int m = l + 1; m < alfabeto.length(); m++) {
////                            for (int n = m + 1; n < alfabeto.length(); n++) {
//
//                                String combinacao = "" + alfabeto.charAt(i)
//                                        + alfabeto.charAt(j) + alfabeto.charAt(k) + alfabeto.charAt(l) + alfabeto.charAt(m);
//                                combinacoes.add(combinacao);
////                            }
//                        }
//                    }
//                }
//            }
//        }
//        Collections.shuffle(combinacoes);
        System.out.println("Número de combinações: " + combinacoes.size());
        return combinacoes;
    }

    public static void main(String[] args) throws IOException {
        List<String> senhasGeradas = combinarLetras();

        // Ler o arquivo de texto que contém as senhas corretas
        BufferedReader senhaReader = new BufferedReader(new FileReader("C:\\Users\\User\\Documents\\teste0105\\usuariosenhacerto.txt"));
        String linha;
        List<String> senhasCorretas = new ArrayList<>();

        while ((linha = senhaReader.readLine()) != null) {
            senhasCorretas.add(linha);
        }

        senhaReader.close();

        // Comparar as combinações com as senhas corretas
        for (String senha : senhasGeradas) {
//                System.out.println(senha); // Adicione esta linha para verificar as combinações geradas

            if (senhasCorretas.contains(senha)) {
                System.out.println("COMBINAÇÃO CORRETA ENCONTRADA: " + senha);
//            } else {
//                System.out.println("Combinação incorreta: " + senha);
            }
        }
    }

}
