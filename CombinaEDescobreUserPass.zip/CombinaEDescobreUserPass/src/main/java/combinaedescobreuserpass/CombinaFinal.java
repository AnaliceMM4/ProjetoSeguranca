//package combinaedescobreuserpass;
//
//import static Post.CombinaAlfabeto.combinarLetras;
//import Post.Post;
//import java.io.BufferedReader;
//import java.io.FileReader;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;
//
///**
// *
// * @author Analice
// */
//public class CombinaFinal {
//
//    public static List<String> combinarLetras() {
//        List<String> combinacoes = new ArrayList<>();
//        String alfabeto = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
//
//        for (int i = 0; i < alfabeto.length() - 3; i++) {
//            for (int j = i + 1; j < alfabeto.length() - 2; j++) {
//                for (int k = j + 1; k < alfabeto.length() - 1; k++) {
//                    for (int l = k + 1; l < alfabeto.length(); l++) {
//                        String combinacao = "" + alfabeto.charAt(i) + alfabeto.charAt(j) + alfabeto.charAt(k) + alfabeto.charAt(l);
//                        combinacoes.add(combinacao);
//                    }
//                }
//            }
//        }
//
////        System.out.println("Número de combinações: " + combinacoes.size());
//        return combinacoes;
//    }
//
//    public static void main(String[] args) throws IOException {
//
//        // 1. Ler os arquivos de texto que contêm usuários e senhas
//        ArrayList<String> senhasteste = new ArrayList<>();
//        senhasteste = (ArrayList<String>) combinarLetras();
//        BufferedReader combinacoesReader = new BufferedReader(new FileReader("C:\\\\Users\\\\User\\\\Documents\\\\teste0105\\\\usuariosenhacerto.txt"));
//
//        // 2. Armazenar os usuários e senhas em arrays
//        String linha;
//
////        while ((linha = senhasteste) != null) {
////            if (!linha.trim().isEmpty()) {
////                senhasteste.add(linha);
////            }
////        }
////        String[] senhas = senhasteste.toArray(new String[0]);
////        System.out.println("SENHAS: " + senhasteste);
//        // 3. Gerar todas as possíveis combinações de usuários e senhas
////        for (int i = 0; i < usuarios.length; i++) {
////            for (int j = 0; j < senhas.length; j++) {
////                String combinacao = "User " + usuarios[i] + "\tPassword " + senhas[j];
////                System.out.println("COMBINAÇÕES: " + combinacao);
////            }
////        }
//        // 4. Comparar as combinações com outro arquivo de texto
//        while ((linha = combinacoesReader.readLine()) != null) {
//
//            boolean encontrouComb = false;
//
//            for (int j = 0; j < senhasteste.size(); j++) {
//                if (senhasteste.get(j).equals(combinacoesReader)) {
//                    encontrouComb = true;
//                    break;
//                }
//                if (encontrouComb) {
//                    break;
//                }
//                
//                if (encontrouComb) {
//                    System.out.println("\nCombinação correta encontrada: " + linha);
//                } else {
//                    System.out.println("\nCombinação incorreta: " + linha);
//                }
//
//            }
//
//            // 5. Fechar os leitores de arquivos
////            usuarioReader.close();
////            senhaReader.close();
//            combinacoesReader.close();
//
//            List<String> resultado = combinarLetras();
//            for (String combinacao : resultado) {
//                System.out.println(combinacao);
//            }
//
//        }
//    }
//}
